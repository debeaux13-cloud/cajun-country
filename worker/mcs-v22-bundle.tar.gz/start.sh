#!/usr/bin/env bash
set -euo pipefail
echo "MCS worker boot: preparing complete production runtime"
export DEBIAN_FRONTEND=noninteractive
if ! command -v ffmpeg >/dev/null 2>&1 || ! command -v ffprobe >/dev/null 2>&1; then
  apt-get update
  apt-get install -y --no-install-recommends ffmpeg ca-certificates
  rm -rf /var/lib/apt/lists/*
fi
mkdir -p /opt/mcs
cp -R /opt/mcs-bundle/. /opt/mcs/
python -m pip install --no-cache-dir -r /opt/mcs/requirements.txt
cd /opt/mcs
echo "MCS worker bundle: 2026-08-27-mcs-v22-autonomous-production-runtime"
echo "MCS worker boot: starting RunPod handler"
exec python -u handler.py

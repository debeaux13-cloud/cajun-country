#!/usr/bin/env bash
set -euo pipefail
echo "MCS worker boot: installing lightweight orchestration dependencies"
mkdir -p /opt/mcs
cp -R /opt/mcs-bundle/. /opt/mcs/
python -m pip install --no-cache-dir -r /opt/mcs/requirements.txt
cd /opt/mcs
echo "MCS worker bundle: 2026-08-27-mcs-v21-safe-local-motion-fallback"
echo "MCS worker boot: starting RunPod handler"
exec python -u handler.py

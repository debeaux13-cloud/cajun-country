# Tier-1 worker licensing boundary

- LivePortrait human inference code: MIT.
- MediaPipe face detection code and model: Apache-2.0.
- The worker deletes LivePortrait's bundled InsightFace model directory during its image build and invokes human inference with source auto-cropping disabled.
- Stable Video Diffusion, X-Pose, and LivePortrait animal mode are not installed or called.
- Both paid tiers route every scene to Runway so the 18-scene/3-minute or 30-scene/5-minute movie matches the obvious movement shown in the free preview.
- Future Tier 2 may add higher-end motion controls, but the current $49 product never substitutes still-image drift for character movement.
- The same worker plans exactly 18 or 30 story-locked scenes, creates every still, narrates every scene, assembles a verified 3-minute or 5-minute MP4 with FFmpeg, and creates the matching PDF bonus only after the movie.
- Per-scene narration calls ElevenLabs' Text-to-Speech endpoint with Flash v2.5 by default. Flash v2.5 supports multilingual narration, and the scene planner preserves the customer's original language. Only the higher-cost model family named Multilingual v2 is excluded from this tier.
- `ELEVENLABS_API_KEY` is read only from the worker's secret environment. `ELEVENLABS_VOICE_ID` and optional `ELEVENLABS_MODEL_ID` are runtime settings and no credential is embedded in this image or repository.

The image build downloads the official MediaPipe BlazeFace short-range detector to `/models/blaze_face_short_range.tflite`; no separate detector mount is required.
